export class createModel {
    intent : string; 
    description : string;
    expression : string[];
};