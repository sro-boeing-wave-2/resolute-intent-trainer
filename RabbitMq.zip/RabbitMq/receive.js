const request = require('superagent');
const { USER_SLUG, BOT_SLUG, RABBITMQ_QUEUE, RECAST_AUTHORIZATION } =
  require('./app.config');

const amqplib = require('amqplib')

const createOrUpdateIntentOnRecast = (msg) => {
  if (msg !== null) {
    var data = JSON.parse(msg.content);
    var route = msg.properties.headers["action"];
    if (route == "create") {
      data.expression.forEach(element, index => {
        if (index == 0)
          CreateIntent(USER_SLUG, BOT_SLUG, data.intent, data.description, element)
        else
          AddToIntent(USER_SLUG, BOT_SLUG, element, data.intent.toLowerCase())
      });
      channel.ack(msg);
    }
    else if (route == "update") {
      AddToIntent(USER_SLUG, BOT_SLUG, data.expression[0], data.intent.toLowerCase())
      channel.ack(msg);
    }
  }
};

module.exports = (async () => {
  const q = RABBITMQ_QUEUE;
  const connection = await amqplib.connect('amqp://localhost');
  const channel = connection.createChannel();
  const channelExists = await channel.assertQueue(q);
  if (channelExists) {
    channel.consume(q, createOrUpdateIntentOnRecast(msg));
  }
})()

// open.then(function (conn) {
//   return conn.createChannel();
// }).then(function (ch) {
//   return ch.assertQueue(q).then(function (ok) {
//     return ch.consume(q, function (msg) {
//       if (msg !== null) {
//         var data = JSON.parse(msg.content);
//         console.log(data);
//         var route = msg.properties.headers["action"];
//         console.log(route);
//         if (route == "create") {
//           data.expression.forEach(element => {
//             console.log(element)
//             CreateIntent(USER_SLUG, BOT_SLUG, data.intent, data.description, element)
//           });
//           ch.ack(msg);
//         }
//         else if (route == "update") {
//           console.log(data.intent);
//           AddToIntent(USER_SLUG, BOT_SLUG, data.expression[0], data.intent.toLowerCase())
//           ch.ack(msg);
//         }
//       }
//     });
//   });
// }).catch(console.warn);




CreateIntent = (USER_SLUG, BOT_SLUG, NAME, DESCRIPTION, QUERY) => {
  request
    .post(`https://api.recast.ai/v2/users/${USER_SLUG}/bots/${BOT_SLUG}/intents`)
    .send({
      name: NAME,
      description: DESCRIPTION,
      expressions: [
        { source: QUERY, language: { isocode: 'en' } }
      ]
    })
    .set('Authorization', RECAST_AUTHORIZATION)
    .end((err, res) => console.log(res.text));
}

AddToIntent = (USER_SLUG, BOT_SLUG, QUERY, INTENT_SLUG) => {
  request
    .post(`https://api.recast.ai/v2/users/${USER_SLUG}/bots/${BOT_SLUG}/intents/${INTENT_SLUG}/expressions`)
    .send({
      source: QUERY,
      language: { isocode: 'en' }
    })
    .set('Authorization', 'Token 286f39a783c97af71459a71423620eec')
    .end((err, res) => console.log(res.text));
};

