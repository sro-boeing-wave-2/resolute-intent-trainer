const config = {
  USER_SLUG: 'amisrikanth',
  BOT_SLUG: 'resolute',
  RABBITMQ_QUEUE: 'ticket',
  RECAST_AUTHORIZATION: 'Token 286f39a783c97af71459a71423620eec'
};

module.exports = config;